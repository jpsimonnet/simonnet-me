---
type: qcm-multiple
question: "Parmi ces œuvres, lesquelles ont été écrites par Victor Hugo ? (plusieurs réponses possibles)"
points: 2
explication: "Victor Hugo a écrit *Hernani* (drame, 1830), *Les Contemplations* (poèmes, 1856) et *Quatrevingt-treize* (roman, 1874). *Germinal* est d'Émile Zola et *Madame Bovary* de Gustave Flaubert."
---

- [x] Hernani
- Germinal
- [x] Les Contemplations
- Madame Bovary
- [x] Quatrevingt-treize
