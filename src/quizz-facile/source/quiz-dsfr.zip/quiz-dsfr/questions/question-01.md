---
type: qcm
question: "Dans quel roman Victor Hugo décrit-il la bataille de Waterloo ?"
points: 1
explication: "C'est dans *Les Misérables* que Victor Hugo consacre de nombreux chapitres à une reconstitution saisissante de la bataille de Waterloo, vue du côté des vaincus."
---

- Notre-Dame de Paris
- Les Travailleurs de la mer
- [x] Les Misérables
- Quatrevingt-treize
