---
type: texte-libre
question: "En quelle année Victor Hugo est-il mort ?"
points: 1
reponse: "1885"
tolerance: exacte
explication: "Victor Hugo est décédé le 22 mai 1885 à Paris, à l'âge de 83 ans. Ses funérailles nationales ont rassemblé près de deux millions de personnes."
---
